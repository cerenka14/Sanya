<?php

$config = new Phalcon\Config(array(

    /**
     * Настройки подключения к базе данных
     */

    'database' => array(
        'host' => 'localhost',
        'username' => 'root',
        'password' => 'gPsyzdfR57Pj',
        'dbname' => 'site'
    ),

    /**
     * Настройка путей для Phalcon
     */

    'phalcon' => array(
        'controllersDir' => '../app/controllers/',
        'modelsDir' => '../app/models/',
        'helpersDir' => '../app/helpers/'
    ),

    /**
     * Настрйка InterKassa
     */

    'interkassa' => array(
        'merchant_id' => '580b8b2f3b1eafdb798b4567',
        'secret_key' => 'rKuuEvEFa1EgwD3Z',
        'test_key' => 'iHrzlevRQpFmWRea'
    ),

    /**
     * Настройки сайта
     */

    'settings' => array(
	'profit' => 22000,
        'email' => 'support@funcash.ru',
        'min_withdraw' => 100,
        'max_withdraw' => 10000
    ),
    /**
     * Настройка авторизации
     */

    'vk' => array(
        'client_id'     => '5681740',
        'client_secret'  => '3Ea1CHAQAm2zQC54LY9c',
        'redirect_uri' => 'http://' . $_SERVER['HTTP_HOST'] . '/auth',
    )
));