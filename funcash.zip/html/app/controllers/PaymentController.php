<?php

use Phalcon\Mvc\Controller;

class PaymentController extends Controller
{

    public $user;

    /**
     * Проверка авторизации
     */

    public function onConstruct()
    {
        $this->user = Users::FindFirst($this->session->get("id"));
    }

    /**
     * Перенапрвление на оплату
     */

    public function indexAction()
    {
        if (!$this->session->has("auth")) {
            $this->response->redirect();
        }

        $transaction = Transactions::Find()->getLast();
       $transaction_id = rand(100000000,999999999);

        $this->response->redirect("https://sci.interkassa.com/?ik_co_id=" . $this->config->interkassa->merchant_id . "&ik_pm_no=" . $transaction_id . "&ik_am=" . $_POST["amount"] . "&ik_desc=Пополнение баланаса на сумму " . $_POST["amount"] . " Рублей&ik_x_user=" . $this->user->id . "");
    }

    /**
     * Вывод срелств с проекта
     */

    public function withdrawAction() {
        if (!$this->session->has("auth")) {
            $this->JsonMessage(false, "Вы не авторизированны !");
        }
        
        if ($_POST['amount'] >= $this->config->settings->min_withdraw && $_POST['amount'] <= $this->config->settings->max_withdraw) {
            if ($this->user->balance >= $_POST['amount']) {

                if ($_POST['type'] == 'webmoney') {

                    if (!preg_match('/R\d\d\d\d\d\d\d\d\d\d\d/', $_POST['purse'])) {
                        $data = [
                            "success" => false,
                            "message" => "Неверный номер счета WebMoney<br>Пример: R23884920195"
                        ];

                        exit(json_encode($data));
                    }

                    $service = 2;
                    $description = "Вывод средств на WebMoney " . $_POST['purse'];
                } elseif ($_POST['type'] == 'yandex') {

                    if (!preg_match('/4\d\d\d\d\d\d\d\d\d\d\d\d\d/', $_POST['purse'])) {
                        $data = [
                            "success" => false,
                            "message" => "Неверный номер счета Яндекс Денег<br>Пример: 41006643106801"
                        ];

                        exit(json_encode($data));
                    }

                    $service = 3;
                    $description = "Вывод средств на Яндекс.Деньги " . $_POST['purse'];
                } elseif ($_POST['type'] == 'qiwi') {

                    if (!preg_match('/\d\d\d\d\d\d\d\d\d\d\d/', $_POST['purse'])) {

                        $data = [
                            "success" => false,
                            "message" => "Неверный номер счета QIWI<br>Пример: 79001234567"
                        ];

                        exit(json_encode($data));
                    }

                    $service = 4;
                    $description = "Вывод средств на Qiwi " . $_POST['purse'];
                } else {
                    $data = [
                        "success" => false,
                        "message" => "Выбраный сервис не существует"
                    ];

                    exit(json_encode($data));
                }

                $this->user->balance -= $_POST['amount'];
                $this->user->save();

                $transaction = Transactions::CreateObject([
                    "user_id" => $this->user->id,
                    "service" => $service,
                    "cost" => - $_POST['amount'],
                    "description" => $description,
                    "status" => 0,
                    "time" => time()
                ]);

                $transaction->save();

                $data = [
                    "success" => true,
                    "balance" => $this->user->balance,
                    "message" => "Запрос на вывод средств успешно создан.<b>В течении 24 часов мы его обработаем</b>"
                ];

                return json_encode($data);

            } else {
                $data = [
                    "success" => false,
                    "message" => "Недостаточно средств на балансе"
                ];

                return json_encode($data);
            }
        } else {
            $data = [
                "success" => false,
                "message" => "Минимальная сумма вывода <b>" . $this->config->settings->min_withdraw . "</b> р<br>Максимальная сумма вывода <b>" . $this->config->settings->max_withdraw . "</b> р"
            ];

            return json_encode($data);
        }
    }

    /**
     * Проверка оплаты зачисление баланаса на сайт
     */

    public function checkAction()
    {

        if ($_POST['ik_co_id'] != $this->config->interkassa->merchant_id) {
            return false;
        }

        $ik_key = ($_POST['ik_pw_via'] == 'test_interkassa_test_xts') ? $this->config->interkassa->test_key : $this->config->interkassa->secret_key;

        /**
         * Формированние массива для создание SIGN
         */

        $data = array();

        foreach ($_POST as $key => $value) {
            if (!preg_match('/ik_/', $key))
                continue;
            $data[$key] = $value;
        }

        $ik_sign = $data['ik_sign'];

        unset($data['ik_sign']);

        ksort($data, SORT_STRING);
        array_push($data, $ik_key);

        $signString = implode(':', $data);
        $sign = base64_encode(md5($signString, true));

        if ($sign === $ik_sign && $data['ik_inv_st'] == 'success') {

                        $transaction = Transactions::FindFirst("ik_pm_no = " . $_POST['ik_pm_no']);

            if (!$transaction) {
                $transaction = Transactions::CreateObject([
				    "ik_pm_no" => $_POST['ik_pm_no'],
                    "user_id" => $_POST['ik_x_user'],
                    "service" => 1,
                    "cost" => $_POST['ik_am'],
                    "description" => "Пополнение баланса через InterKassa",
                    "status" => 1,
                    "time" => time()
                ]);

                $transaction->save();

                $user = Users::FindFirst($_POST['ik_x_user']);

                $user->balance += $_POST['ik_am'];
                $user->save();

                if ($user->referral != NULL) {
                    $ref = $user->referral;
                    $user = Users::FindFirst("referral_code='$ref'");
                    $user->balance += $_POST['ik_am'] * 0.1;
                    $user->save();
                }
            }

        } else {
            return false;
        }
    }

    /**
     * Успешная оплата
     */

    public function successAction()
    {
        $this->view->user = $this->user;

        $this->view->pick("site/pages/payment/success");
    }

    /**
     * Не успешная оплата
     */

    public function failAction()
    {
        $this->view->user = $this->user;

        $this->view->pick("site/pages/payment/fail");
    }

}